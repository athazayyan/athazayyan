Achmad Atha Zayyan
2308107010033

problem 1:
Saya membaginya menjadi dua, 1.bulan yang dengan tahun kabisat, 2 bulan yng dengan tahun bukan kabisat. Menulis codingannya 2 kali berulang. segmen 1 dengan if dan segmen 2 dengan else, yang masing masingnya dipergunakan nested if.

problem 2:
saya membuatnya dengan do while. dengan penyelesaiannya sesuai urutan dari nominal terbesar dan seleksi pertama dengan uang yang dibagi nominal dan modulo untuk mengantarkan uang yang masih ada sisa ke urutan nominal uang yang lebih kecil... begitu hingga uang 1 rupiah.

terima kasih

wassalam

Atha Zayyan
