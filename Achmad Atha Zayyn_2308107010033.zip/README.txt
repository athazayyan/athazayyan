Achmad Atha Zayyan 
2308107010033

problem 1: 
kita disuruh untuk mengubah huruf dan mengeluarkannya dengan sebuah fungsi. Maka,  yang pertama kita lakukan adalah membiarkan pengguna untuk menginput data, huruf apa yang ingin diganti serta huruf penggantinya. Kemudian digunakan perulangan di dalam fungsi untuk dapat mendeteksi huruf yangsama dalam string, huruf yanng sama itu kemudian diganti dengan huruf baru sesui dengan index yang dimilikinya.

problem 2:
Kita disuruh untuk mentranslasi sebuah string. Ketika pengguna sudah menginput string, berapa kali mau digeser, dan arah geser, maka kita mengecilkan semua stringnya dengan perulangan dan dengan 'if'. setelah itu masuk ke fungsi. karena 'kanan' dan 'kiri' hanya ada beda di inde ke-1 yaitu 'a' dan 'i'. maka saya gunakan untuk masuk ke fungsi.. dengan awalnya membaginya menjadi dua sesuai arah kiridan kanan. kemudian rumus data[i] = a + (data[i] - a + berapapergeserannya) % 26; atau data[i] = a + (data[i] - a - berapapergeserannya) % 26; dan dibantu dengan for untukmenggeser satu satu huruf dari index 0 hingga terkahir maka huruf akan tergeser.