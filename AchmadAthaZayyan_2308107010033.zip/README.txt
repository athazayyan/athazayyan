ACHMAD ATHA ZAYYAN
2308107010033

problem 1;
kita diharuskan untuk menentukan berapa banyak jumlah data yang akan diinput dan nilai data yang bakal diinput. untuk jumlah data sendiri dibatasi hingga 80. yang pertama yang dilakukan adalah membagi menjadi dua yaitu inputan 1-80 dan diluarnya, dengan if (1-80) dan else. kita hanya akan memeroses yang if. Setelah itu kita mencari min dan maks data dengan menggunakan array nya sendiri untuk membandingkan antara satu dan lainnya sehingga memperoleh data yang aling besar dan yang paling kecil. Kita juga membuat nilai total dengan menjumlahkan semua array nya dengan sendirinya dan dibagikan dengan jumlah data yang diinputkan.

problem 2;
kita membagikannya menjadi 4 buah bagian. bagian 1, untuk menginputkan kalimat. bagian 2, untuk mengubah semua klimat menjadi kecil. bagian 3 untuk mengubah huruf awal menjadi besar.bagian 4 untuk mengubah huruf setelah spasi menjadi besar. mengubah ini membutuh perulangan untuk memeriksa setiap kata. kemudian langsung menggunakan 'a' - 'z' tanpa mengonversikannya menjadi angka terlebih dahulu.

problem 3;
secara teknis. merubah semuanya menjadi huruf kecil sangat mirip dengan yang terjadi di problem 2. Kemudian setelah dibantu dengan perulangannya, membalikkan kalimat hanya butuh memanggil array dari indeks yang belakang. 